import { db, auth } from "../firebase/firebase-config.js";
import { collection, query, where, orderBy, limit, getDocs } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

export async function getRecommendations() {
    if (!auth.currentUser) return [];
    
    // Get last 5 played genres
    const historyQ = query(collection(db, "history"), where("uid", "==", auth.currentUser.uid), orderBy("timestamp", "desc"), limit(5));
    const historySnap = await getDocs(historyQ);
    const genres = historySnap.docs.map(d => d.data().genre);

    if (genres.length === 0) return [];

    // Query songs with same genres
    const recQ = query(collection(db, "songs"), where("genre", "in", [...new Set(genres)]), limit(10));
    const recSnap = await getDocs(recQ);
    return recSnap.docs.map(d => ({ id: d.id, ...d.data() }));
}