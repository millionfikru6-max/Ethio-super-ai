import { auth, db } from "../firebase/firebase-config.js";
import { 
    onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword, 
    GoogleAuthProvider, signInWithPopup, signOut, sendPasswordResetEmail 
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { doc, setDoc, getDoc } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const navLinks = document.getElementById('nav-links');

onAuthStateChanged(auth, async (user) => {
    if (user) {
        const userDoc = await getDoc(doc(db, "users", user.uid));
        const userData = userDoc.data();
        updateNav(true);
        if (userData?.theme === 'light') document.body.classList.add('light-mode');
    } else {
        updateNav(false);
    }
});

function updateNav(isLoggedIn) {
    if (isLoggedIn) {
        navLinks.innerHTML = `
            <li><a href="${location.pathname.includes('pages/') ? '../index.html' : 'index.html'}">Home</a></li>
            <li><a href="${location.pathname.includes('pages/') ? 'profile.html' : 'pages/profile.html'}">Profile</a></li>
            <li><a href="${location.pathname.includes('pages/') ? 'settings.html' : 'pages/settings.html'}">Settings</a></li>
            <li><a href="#" id="logout-link">Logout</a></li>
        `;
        document.getElementById('logout-link').addEventListener('click', () => signOut(auth));
    } else {
        navLinks.innerHTML = `
            <li><a href="${location.pathname.includes('pages/') ? '../index.html' : 'index.html'}">Home</a></li>
            <li><a href="#" id="nav-login">Login</a></li>
        `;
    }
}

// Signup Logic
export async function handleSignup(email, password, name) {
    const cred = await createUserWithEmailAndPassword(auth, email, password);
    await setDoc(doc(db, "users", cred.user.uid), {
        uid: cred.user.uid,
        displayName: name,
        email: email,
        bio: "Initializing neural bio...",
        role: "User",
        theme: "dark",
        followers: 0,
        createdAt: new Date().toISOString()
    });
}
document.addEventListener('click', (e) => {
    if (e.target.id === 'nav-login') {
        const modal = document.getElementById('auth-modal');
        if (modal) modal.classList.remove('hidden');
    }
});

// Login/Signup Toggle
document.getElementById('toggle-signup')?.addEventListener('click', () => {
    document.getElementById('login-form').classList.add('hidden');
    document.getElementById('signup-form').classList.remove('hidden');
});

document.getElementById('toggle-login')?.addEventListener('click', () => {
    document.getElementById('signup-form').classList.add('hidden');
    document.getElementById('login-form').classList.remove('hidden');
});

// Close Modal
document.querySelector('.close-modal')?.addEventListener('click', () => {
    document.getElementById('auth-modal').classList.add('hidden');
});

// Auth Actions
document.getElementById('btn-do-login')?.addEventListener('click', async () => {
    const email = document.getElementById('login-email').value;
    const pass = document.getElementById('login-password').value;
    try {
        await signInWithEmailAndPassword(auth, email, pass);
        document.getElementById('auth-modal').classList.add('hidden');
    } catch (err) {
        alert(err.message);
    }
});

document.getElementById('btn-do-signup')?.addEventListener('click', async () => {
    const name = document.getElementById('signup-name').value;
    const email = document.getElementById('signup-email').value;
    const pass = document.getElementById('signup-password').value;
    try {
        await handleSignup(email, pass, name);
        document.getElementById('auth-modal').classList.add('hidden');
    } catch (err) {
        alert(err.message);
    }
});

document.getElementById('btn-google-login')?.addEventListener('click', async () => {
    try {
        const provider = new GoogleAuthProvider();
        await signInWithPopup(auth, provider);
        document.getElementById('auth-modal').classList.add('hidden');
    } catch (err) {
        alert(err.message);
    }
});
