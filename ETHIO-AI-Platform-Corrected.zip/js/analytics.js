import { db } from "../firebase/firebase-config.js";
import { doc, setDoc, increment, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

export async function trackSession() {
    const today = new Date().toISOString().split('T')[0];
    const analyticsRef = doc(db, "analytics", today);
    
    await setDoc(analyticsRef, {
        dailyActiveUsers: increment(1),
        lastUpdated: serverTimestamp()
    }, { merge: true });
}

trackSession();