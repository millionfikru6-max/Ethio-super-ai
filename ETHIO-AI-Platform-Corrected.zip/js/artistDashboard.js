import { db, auth } from "../firebase/firebase-config.js";
import { collection, query, where, getDocs, orderBy, limit } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

auth.onAuthStateChanged(async user => {
    if (!user) return;
    
    // Fetch Artist Songs
    const q = query(collection(db, "songs"), where("uploaderUID", "==", user.uid));
    const snap = await getDocs(q);
    
    let totalPlays = 0;
    let totalLikes = 0;
    const songData = [];

    snap.forEach(doc => {
        const d = doc.data();
        totalPlays += d.playCount || 0;
        totalLikes += d.likes || 0;
        songData.push(d);
    });

    document.getElementById('stat-total-plays').innerText = totalPlays.toLocaleString();
    document.getElementById('stat-likes').innerText = totalLikes.toLocaleString();

    // Render Chart (Placeholder logic)
    const ctx = document.getElementById('playsChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: songData.map(s => s.title).slice(0, 7),
            datasets: [{
                label: 'Plays per Song',
                data: songData.map(s => s.playCount).slice(0, 7),
                borderColor: '#00f2ff',
                tension: 0.4
            }]
        },
        options: { responsive: true, plugins: { legend: { labels: { color: '#fff' } } } }
    });
});