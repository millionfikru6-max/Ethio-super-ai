const CACHE_NAME = 'ethio-ai-v1';
const ASSETS = [
  './index.html',
  './index.html',
  './css/style.css',
  './js/main.js',
  './pages/offline.html',
  './assets/music/loyal.m4a'
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS)));
});

self.addEventListener('fetch', (e) => {
  e.respondWith(
    fetch(e.request).catch(() => caches.match(e.request) || caches.match('./pages/offline.html'))
  );
});