import { songList } from './player.js';

const searchInput = document.getElementById('global-search');

searchInput.addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase();
    const cards = document.querySelectorAll('.song-card');

    songList.forEach((song, index) => {
        const isVisible = 
            song.title.toLowerCase().includes(term) || 
            song.artist.toLowerCase().includes(term) || 
            (song.album && song.album.toLowerCase().includes(term));
        
        cards[index].style.display = isVisible ? 'block' : 'none';
    });
});