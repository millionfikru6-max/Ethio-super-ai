import { db } from "../firebase/firebase-config.js";
import { collection, query, orderBy, onSnapshot } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { loadTrack, songList } from './player.js';

const libraryGrid = document.getElementById('music-library');

export function initLibrary() {
    const q = query(collection(db, "songs"), orderBy("uploadDate", "desc"));

    onSnapshot(q, (snapshot) => {
        libraryGrid.innerHTML = '';
        const songs = [];
        
        snapshot.forEach((doc) => {
            const song = { id: doc.id, ...doc.data() };
            songs.push(song);
            renderSongCard(song, songs.length - 1);
        });

        // Update global song list for player
        songList.length = 0;
        songList.push(...songs);
    });
}

function renderSongCard(song, index) {
    const card = document.createElement('div');
    card.className = 'song-card reveal active';
    card.innerHTML = `
        <img src="${song.coverImageURL}" alt="${song.title}">
        <h3>${song.title} ${song.verifiedArtist ? '<span class="verified-badge">✔</span>' : ''}</h3>
        <p>${song.artist}</p>
        <p style="font-size: 0.7rem; opacity: 0.6;">${song.album || 'Single'}</p>
    `;

    card.addEventListener('click', () => {
        loadTrack(index);
    });

    libraryGrid.appendChild(card);
}

initLibrary();