import { db, auth } from "../firebase/firebase-config.js";
import { doc, setDoc, deleteDoc, collection, query, where, onSnapshot, getDocs, serverTimestamp, increment, updateDoc } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

// FOLLOW SYSTEM
export async function toggleFollow(targetUid, isFollowing) {
    const followerId = auth.currentUser.uid;
    const followId = `${followerId}_${targetUid}`;
    const followRef = doc(db, "follows", followId);

    if (isFollowing) {
        await deleteDoc(followRef);
        await updateDoc(doc(db, "users", targetUid), { followers: increment(-1) });
    } else {
        await setDoc(followRef, { followerId, targetUid, timestamp: serverTimestamp() });
        await updateDoc(doc(db, "users", targetUid), { followers: increment(1) });
        createNotification(targetUid, "follow", "started following you");
    }
}

// LIKES
export async function toggleLike(songId, currentLikes, isLiked) {
    const uid = auth.currentUser.uid;
    const likeId = `${uid}_${songId}`;
    const likeRef = doc(db, "likes", likeId);

    if (isLiked) {
        await deleteDoc(likeRef);
        await updateDoc(doc(db, "songs", songId), { likes: increment(-1) });
    } else {
        await setDoc(likeRef, { uid, songId, timestamp: serverTimestamp() });
        await updateDoc(doc(db, "songs", songId), { likes: increment(1) });
    }
}

// COMMENTS
export async function addComment(songId, text) {
    const commentRef = collection(db, "comments");
    await setDoc(doc(commentRef), {
        songId,
        uid: auth.currentUser.uid,
        userName: auth.currentUser.displayName,
        text,
        timestamp: serverTimestamp()
    });
}

// NOTIFICATIONS
export async function createNotification(targetUid, type, message) {
    if (targetUid === auth.currentUser.uid) return;
    await setDoc(doc(collection(db, "notifications")), {
        targetUid,
        fromUid: auth.currentUser.uid,
        fromName: auth.currentUser.displayName,
        type,
        message,
        read: false,
        timestamp: serverTimestamp()
    });
}