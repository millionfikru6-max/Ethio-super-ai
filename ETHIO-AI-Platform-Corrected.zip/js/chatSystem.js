import { db, auth } from "../firebase/firebase-config.js";
import { collection, addDoc, query, where, orderBy, onSnapshot, serverTimestamp, doc, setDoc } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

export function listenToMessages(chatId, callback) {
    const q = query(collection(db, `chats/${chatId}/messages`), orderBy("timestamp", "asc"));
    return onSnapshot(q, (snapshot) => {
        const messages = snapshot.docs.map(d => d.data());
        callback(messages);
    });
}

export async function sendMessage(chatId, text) {
    const msgRef = collection(db, `chats/${chatId}/messages`);
    await addDoc(msgRef, {
        senderId: auth.currentUser.uid,
        senderName: auth.currentUser.displayName,
        text,
        timestamp: serverTimestamp()
    });
    
    await updateDoc(doc(db, "chats", chatId), {
        lastMessage: text,
        lastTimestamp: serverTimestamp()
    });
}