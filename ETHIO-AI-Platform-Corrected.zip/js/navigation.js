// ... existing auth imports ...

function updateNav(isLoggedIn) {
    const navLinks = document.getElementById('nav-links');
    if (isLoggedIn) {
        navLinks.innerHTML = `
            <li><a href="../index.html">Home</a></li>
            <li><a href="../pages/upload.html" class="neon-blue">Upload</a></li>
            <li><a href="../pages/profile.html">Profile</a></li>
            <li><a href="../pages/settings.html">Settings</a></li>
            <li><a href="#" id="logout-link">Logout</a></li>
        `;
        document.getElementById('logout-link').addEventListener('click', () => signOut(auth));
    } else {
        navLinks.innerHTML = `
            <li><a href="../index.html">Home</a></li>
            <li><a href="#" id="nav-login">Login</a></li>
        `;
    }
}