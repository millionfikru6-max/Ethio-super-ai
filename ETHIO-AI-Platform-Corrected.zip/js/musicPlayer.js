import { db, auth } from "../firebase/firebase-config.js";
import { doc, updateDoc, increment, setDoc, collection, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

export const songList = [];
let currentTrackIndex = 0;
const audio = new Audio();

export async function loadTrack(index) {
    currentTrackIndex = index;
    const track = songList[currentTrackIndex];
    audio.src = track.audioURL;
    
    // Update Playback UI (Previous logic kept...)
    playTrack();

    // PHASE 3: Analytics & History
    if (auth.currentUser) {
        // Update Recently Played
        const historyId = `${auth.currentUser.uid}_${track.id}`;
        await setDoc(doc(db, "history", historyId), {
            uid: auth.currentUser.uid,
            songId: track.id,
            timestamp: serverTimestamp(),
            ...track
        });

        // Global Play Count (Trending)
        await updateDoc(doc(db, "songs", track.id), {
            playCount: increment(1)
        });
        
        // Daily Analytics
        const today = new Date().toISOString().split('T')[0];
        await setDoc(doc(db, "analytics", today), {
            totalPlays: increment(1)
        }, { merge: true });
    }
}

function playTrack() { audio.play(); }