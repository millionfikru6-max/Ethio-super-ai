import { auth, db } from "../firebase/firebase-config.js";
import { collection, query, where, getDocs } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

async function loadMyUploads(uid) {
    const uploadsContainer = document.getElementById('my-uploads-grid');
    if (!uploadsContainer) return;

    const q = query(collection(db, "songs"), where("uploaderUID", "==", uid));
    const querySnapshot = await getDocs(q);

    uploadsContainer.innerHTML = '';
    querySnapshot.forEach((doc) => {
        const song = doc.data();
        const item = document.createElement('div');
        item.className = 'song-card';
        item.innerHTML = `
            <img src="${song.coverImageURL}">
            <h3>${song.title}</h3>
            <p>Plays: ${song.playCount} | Likes: ${song.likes}</p>
        `;
        uploadsContainer.appendChild(item);
    });
}

auth.onAuthStateChanged(user => {
    if (user) loadMyUploads(user.uid);
});