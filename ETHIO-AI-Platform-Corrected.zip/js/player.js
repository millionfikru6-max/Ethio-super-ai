export const songList = [];
let currentTrackIndex = 0;
let isPlaying = false;
let isRepeat = false;
let isShuffle = false;

const audio = new Audio();
const playerBar = document.getElementById('global-player');
const playPauseBtn = document.getElementById('player-play-pause');
const progressBar = document.getElementById('progress-bar');
const volumeSlider = document.getElementById('volume-slider');
const currentTimeEl = document.getElementById('current-time');
const durationTimeEl = document.getElementById('duration-time');

export function loadTrack(index) {
    currentTrackIndex = index;
    const track = songList[currentTrackIndex];

    audio.src = track.audioURL;
    document.getElementById('player-cover').src = track.coverImageURL;
    document.getElementById('player-title').textContent = track.title;
    document.getElementById('player-artist').textContent = track.artist;

    playerBar.classList.remove('hidden');
    playTrack();
}

function playTrack() {
    audio.play();
    isPlaying = true;
    playPauseBtn.textContent = '⏸';
}

function pauseTrack() {
    audio.pause();
    isPlaying = false;
    playPauseBtn.textContent = '▶';
}

playPauseBtn.addEventListener('click', () => {
    isPlaying ? pauseTrack() : playTrack();
});

document.getElementById('player-next').addEventListener('click', () => {
    nextTrack();
});

document.getElementById('player-prev').addEventListener('click', () => {
    currentTrackIndex = (currentTrackIndex - 1 + songList.length) % songList.length;
    loadTrack(currentTrackIndex);
});

function nextTrack() {
    if (isShuffle) {
        currentTrackIndex = Math.floor(Math.random() * songList.length);
    } else {
        currentTrackIndex = (currentTrackIndex + 1) % songList.length;
    }
    loadTrack(currentTrackIndex);
}

audio.addEventListener('timeupdate', () => {
    const progress = (audio.currentTime / audio.duration) * 100;
    progressBar.value = progress || 0;
    currentTimeEl.textContent = formatTime(audio.currentTime);
    durationTimeEl.textContent = formatTime(audio.duration);
});

progressBar.addEventListener('input', () => {
    audio.currentTime = (progressBar.value / 100) * audio.duration;
});

volumeSlider.addEventListener('input', () => {
    audio.volume = volumeSlider.value / 100;
});

audio.addEventListener('ended', () => {
    if (isRepeat) {
        audio.currentTime = 0;
        playTrack();
    } else {
        nextTrack();
    }
});

document.getElementById('player-repeat').addEventListener('click', (e) => {
    isRepeat = !isRepeat;
    e.target.style.color = isRepeat ? 'var(--blue)' : 'var(--text)';
});

document.getElementById('player-shuffle').addEventListener('click', (e) => {
    isShuffle = !isShuffle;
    e.target.style.color = isShuffle ? 'var(--blue)' : 'var(--text)';
});

function formatTime(seconds) {
    if (isNaN(seconds)) return "0:00";
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
}