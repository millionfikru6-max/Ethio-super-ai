import { db, auth } from "../firebase/firebase-config.js";
import { collection, addDoc, updateDoc, doc, arrayUnion, arrayRemove, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

export async function createPlaylist(title) {
    return await addDoc(collection(db, "playlists"), {
        uid: auth.currentUser.uid,
        title,
        songs: [],
        createdAt: serverTimestamp()
    });
}

export async function addSongToPlaylist(playlistId, songData) {
    const ref = doc(db, "playlists", playlistId);
    await updateDoc(ref, {
        songs: arrayUnion(songData)
    });
}

export async function removeSongFromPlaylist(playlistId, songData) {
    const ref = doc(db, "playlists", playlistId);
    await updateDoc(ref, {
        songs: arrayRemove(songData)
    });
}