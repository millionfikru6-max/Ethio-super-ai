import { auth } from "../firebase/firebase-config.js";

// Register PWA
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register("./service-worker.js");
}

// Global UI Fixes
const modal = document.getElementById('auth-modal');
const showLoginBtn = document.getElementById('show-login');

if(showLoginBtn) {
    showLoginBtn.addEventListener('click', () => modal.classList.remove('hidden'));
}

document.querySelector('.close-modal')?.addEventListener('click', () => {
    modal.classList.add('hidden');
});

// Cursor & Particles logic moved from previous version...