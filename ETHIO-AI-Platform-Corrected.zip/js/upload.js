import { auth, db, storage } from "../firebase/firebase-config.js";
import { ref, uploadBytesResumable, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-storage.js";
import { collection, addDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const uploadForm = document.getElementById('upload-form');
const progressContainer = document.getElementById('upload-progress-container');
const progressFill = document.getElementById('upload-progress-fill');
const statusText = document.getElementById('upload-status');
const messageText = document.getElementById('upload-message');

uploadForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!auth.currentUser) return alert("Please login to upload.");

    const title = document.getElementById('song-title').value;
    const artist = document.getElementById('song-artist').value;
    const album = document.getElementById('song-album').value;
    const genre = document.getElementById('song-genre').value;
    const audioFile = document.getElementById('audio-file').files[0];
    const coverFile = document.getElementById('cover-file').files[0];

    try {
        progressContainer.classList.remove('hidden');
        
        // 1. Upload Audio
        const audioRef = ref(storage, `songs/${Date.now()}_${audioFile.name}`);
        const audioTask = uploadBytesResumable(audioRef, audioFile);
        
        // 2. Upload Cover
        const coverRef = ref(storage, `covers/${Date.now()}_${coverFile.name}`);
        const coverTask = uploadBytesResumable(coverRef, coverFile);

        // Monitor Audio Progress
        audioTask.on('state_changed', (snapshot) => {
            const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            progressFill.style.width = progress + '%';
            statusText.textContent = `Uploading Audio: ${Math.round(progress)}%`;
        });

        await audioTask;
        const audioURL = await getDownloadURL(audioRef);
        
        statusText.textContent = "Uploading Cover Image...";
        await coverTask;
        const coverURL = await getDownloadURL(coverRef);

        // 3. Save to Firestore
        await addDoc(collection(db, "songs"), {
            title,
            artist,
            album,
            genre,
            audioURL,
            coverImageURL: coverURL,
            uploaderUID: auth.currentUser.uid,
            uploaderName: auth.currentUser.displayName || "Unknown Artist",
            uploadDate: serverTimestamp(),
            playCount: 0,
            likes: 0,
            verifiedArtist: false
        });

        messageText.style.color = "var(--blue)";
        messageText.textContent = "Neural Sync Complete! Song is live.";
        uploadForm.reset();
        setTimeout(() => progressContainer.classList.add('hidden'), 3000);

    } catch (error) {
        console.error(error);
        messageText.style.color = "#ff4d4d";
        messageText.textContent = "Sync Error: " + error.message;
    }
});